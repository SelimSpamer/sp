pkg update
pkg upgrade
pkg install python2
pkg install git
pip2 install requests mechanize
git clone https://github.com/SelimSpamer/rkf52
cd rkf52
chmod +x *
python2 rkf52
